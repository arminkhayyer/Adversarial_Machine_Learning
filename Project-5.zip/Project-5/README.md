# Adversarial_m
Adveersarial Machine Learning Dr. Dozier (Fall 2019), Project 5 
 
 
1. Put the text file containing the name of adversarial attacked files in the project directory 
2. Open the setup.py file and modify the directory of the adversarial files: TestFilePath = ""
2. Run the GFES_B.py code and it will output a text file named "AdversarialTestResults.txt" which contains the lables.  




